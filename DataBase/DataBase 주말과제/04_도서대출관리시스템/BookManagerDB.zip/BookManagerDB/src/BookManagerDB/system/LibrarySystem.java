package BookManagerDB.system;

import java.sql.*;
import java.util.*;
import BookManagerDB.presentation.*;
import BookManagerDB.utillities.*;

public class LibrarySystem {
	private static LibrarySystem instance;
	DataHandler dataHandler = DataHandler.getInstance();

	private LibrarySystem() {
	}

	public static LibrarySystem getInstance() {
		if (instance == null) {
			synchronized (LibrarySystem.class) {
				if (instance == null) {
					instance = new LibrarySystem();
				}
			}
		}
		return instance;
	}

	public void open() throws ClassNotFoundException, SQLException {
		dataHandler.connect();
	}

	public void close() throws SQLException {
		dataHandler.disconnect();
	}

	public void showMain() throws SQLException {
		MainView.getInstance().showMain();
	}

	public void showMemberList() throws SQLException {
		System.out.println("========== 회원 조회 ==========");
		System.out.println(" 0. 기본 조회");
		System.out.println(" 1. 회원 이름순 조회");
		System.out.println(" 2. 회원 가입일순 조회");
		System.out.println(" 3. 회원 주소순 조회");
		System.out.println(" 4. 회원 연락처순 조회");
		System.out.println(" 5. 회원 생년월일순 조회");
		System.out.println(" 6. 회원 생일순 조회");
		System.out.println("===============================");
		int selectInput = InputHandler.getInt();
		String sortby;
		switch (selectInput) {
		case 0:
			sortby = "member_id";
			break;
		case 1:
			sortby = "name";
			break;
		case 2:
			sortby = "join_date";
			break;
		case 3:
			sortby = "address";
			break;
		case 4:
			sortby = "contact";
			break;
		case 5:
			sortby = "birthday";
			break;
		case 6:
			sortby = "age";
			break;
		default:
			sortby = "rent_status";
			break;
		}
		String sql = "select * from member order by " + sortby;
		dataHandler.printQuery(sql);
	}

	public void showBookList() throws SQLException {
		System.out.println("========== 도서 조회 ==========");
		System.out.println(" 0. 기본 조회");
		System.out.println(" 1. 도서 이름순 조회");
		System.out.println(" 2. 도서 입고일순 조회");
		System.out.println(" 3. 도서 작가순 조회");
		System.out.println(" 4. 도서 출판사순 조회");
		System.out.println(" 5. 도서 가격순 조회");
		System.out.println(" 6. 도서 출판일순 조회");
		System.out.println("===============================");
		int selectInput = InputHandler.getInt();
		String sortby;
		switch (selectInput) {
		case 0:
			sortby = "book_id";
			break;
		case 1:
			sortby = "name";
			break;
		case 2:
			sortby = "Store_date";
			break;
		case 3:
			sortby = "author";
			break;
		case 4:
			sortby = "publisher";
			break;
		case 5:
			sortby = "price";
			break;
		case 6:
			sortby = "publishing_date";
			break;
		default:
			sortby = "publishing_date";
			break;
		}
		System.out.println("========== 도서 조회 ==========");
		System.out.println(" 0. 뒤로");
		System.out.println(" 1. 도서 전체 조회");
		System.out.println(" 2. 대출 가능한 도서 조회");
		System.out.println("===============================");
		int selectInput1 = InputHandler.getInt();
		String filtering = "";
		switch (selectInput1) {
		case 0:
			return;

		case 1:
			filtering = "";
			break;

		case 2:
			filtering = "where rental_status = '대출가능'";
			break;
		default:
			System.out.println("잘못된 입력");
			break;
		}
		String sql = "select * from book " + filtering + " order by " + sortby;
		dataHandler.printQuery(sql);
	}

	public void showRentalList() throws SQLException {
		System.out.println("========== 회원 조회 ==========");
		System.out.println(" 0. 기본 조회");
		System.out.println(" 1. 도서 ID순 조회");
		System.out.println(" 2. 회원 ID순 조회");
		System.out.println(" 3. 연장 여부순 조회");
		System.out.println(" 4. 대여 일자순 조회");
		System.out.println(" 5. 반납 일자순 조회");
		System.out.println(" 6. 남은 기간순 조회");
		System.out.println("===============================");
		int selectInput = InputHandler.getInt();
		String sortby;
		switch (selectInput) {
		case 0:
			sortby = "rental_id";
			break;
		case 1:
			sortby = "book_id";
			break;
		case 2:
			sortby = "member_id";
			break;
		case 3:
			sortby = "extension";
			break;
		case 4:
			sortby = "rentaldate";
			break;
		case 5:
			sortby = "returndate";
			break;
		case 6:
			sortby = "remaindays";
			break;
		default:
			sortby = "remaindays";
			break;
		}
		String sql = "select * from rent order by " + sortby;
		dataHandler.printQuery(sql);
	}

	public void getMemberData() throws SQLException {
		// 이름 받기
		System.out.print("이름 : ");
		String name = InputHandler.getInput();
		// 주소
		System.out.print("주소 : ");
		String address = InputHandler.getInput();
		// 연락처
		System.out.print("연락처 : ");
		String contact = InputHandler.getInput();
		// 생일
		System.out.print("생일(yyyy/MM/dd) : ");
		String birthday = InputHandler.getInput();
		// 회원 인스턴스 생성
		String sql = "INSERT INTO Member (rent_status, name, join_date, address, contact, birthday, age) VALUES ('대출가능', '"
				+ name + "', TO_DATE(sysdate, 'YYYY-MM-DD'), '" + address + "', '" + contact + "', TO_DATE('" + birthday
				+ "', 'YYYY-MM-DD'), TRUNC((SYSDATE - TO_DATE('" + birthday + "', 'YYYY-MM-DD')) / 365.25))";
		dataHandler.dmlQuery(sql);
		System.out.println("회원이 등록되었습니다.");
	}

	public void getBookData() throws SQLException {
		System.out.print("도서 제목 : ");
		String name = InputHandler.getInput();
		// 도서 출간일 받기
		System.out.print("저자 : ");
		String author = InputHandler.getInput();
		System.out.print("출판사 : ");
		String publisher = InputHandler.getInput();
		// 도서 출간일 받기
		System.out.print("출간 일(yyyy/MM/dd): ");
		String pulishingDate = InputHandler.getInput();
		System.out.print("도서 가격 : ");
		String price = InputHandler.getInput();
		// 책 인스턴스 생성
		String sql = "INSERT INTO book (rental_status, name, author, publisher, publishing_date, price) VALUES ('대출가능', '"
				+ name + "', '" + author + "', '" + publisher + "', to_date('" + pulishingDate + "', 'YYYY-MM-DD'), "
				+ price + ")";
		dataHandler.dmlQuery(sql);
		System.out.println("도서가 등록되었습니다.");
	}

	public void updateMemberData() throws SQLException {
		this.showMemberList();
		System.out.println("수정할 회원 ID : ");
		String updateId = InputHandler.getInput();
		String sql = "select * from member where MEMBER_ID = '" + updateId + "'";
		List<String> updateMember = dataHandler.selectQuery(sql).get(1);
		String name = updateMember.get(2);
		String address = updateMember.get(4);
		String contact = updateMember.get(5);
		String birthday = updateMember.get(6);
		while (true) {
			System.out.println("======== 회원 정보 수정 ========");
			System.out.println(" 0. 수정 완료");
			System.out.println(" 1. 회원 이름");
			System.out.println(" 2. 회원 주소");
			System.out.println(" 3. 회원 연락처");
			System.out.println(" 4. 회원 생일");
			System.out.println(" 5. 수정 취소");
			System.out.println("====================================");
			int memberOptionInput = InputHandler.getInt();
			switch (memberOptionInput) {
			case 0: // 수정 완료
				sql = "update member set name = '" + name + "', address = '" + address + "', contact = '" + contact
						+ "', birthday = TO_DATE('" + birthday + "', 'YYYY-MM-DD'), age = TRUNC((SYSDATE - TO_DATE('"
						+ birthday + "', 'YYYY-MM-DD')) / 365.25) where MEMBER_ID = '" + updateId + "'";
				dataHandler.dmlQuery(sql);
				dataHandler.commit();
				System.out.println("회원 정보가 수정되었습니다.\n");
				return;

			case 1: // 회원 이름
				System.out.println("현재 이름 : " + name + "\n수정할 이름 : ");
				name = InputHandler.getInput();
				break;

			case 2: // 회원 주소
				System.out.println("현재 주소 : " + address + "\n수정할 주소 : ");
				address = InputHandler.getInput();
				break;

			case 3: // 회원 연락처
				System.out.println("현재 연락처 : " + contact + "\n수정할 연락처 : ");
				contact = InputHandler.getInput();
				break;

			case 4: // 회원 생일
				System.out.println("현재 생일" + " : " + birthday + "\n수정할 생일\" : ");
				birthday = InputHandler.getInput();
				break;

			case 5: // 수정 취소
				System.out.println("모든 수정 사항이 초기화 됩니다.\n수정이 취소되었습니다.n");
				dataHandler.rollback();
				return;
			default:
				System.out.println("올바른 값을 입력하세요\n");
				continue;
			}

			System.out.println("변경할 회원 정보를 저장했습니다.");
		}
	}

	public void updateBookData() throws SQLException {
		this.showBookList();
		System.out.println("수정할 도서 ID : ");
		String updateId = InputHandler.getInput();
		String sql = "select * from book where BOOK_ID = '" + updateId + "'";
		List<String> updateBook = dataHandler.selectQuery(sql).get(1);
		String name = updateBook.get(2);
		String author = updateBook.get(4);
		String publisher = updateBook.get(5);
		String publishingDate = updateBook.get(6);
		String price = updateBook.get(7);
		while (true) {
			System.out.println("======== 회원 정보 수정 ========");
			System.out.println(" 0. 수정 완료");
			System.out.println(" 1. 책 이름");
			System.out.println(" 2. 책 작가");
			System.out.println(" 3. 책 출판사");
			System.out.println(" 4. 책 출판일");
			System.out.println(" 5. 책 가격");
			System.out.println(" 6. 수정 취소");
			System.out.println("====================================");
			int BookOptionInput = InputHandler.getInt();

			switch (BookOptionInput) {
			case 0: // 수정 완료
				sql = "update book set name = '" + name + "', author = '" + author + "', publisher = '" + publisher
						+ "', publishing_Date = TO_DATE('" + publishingDate + "', 'YYYY-MM-DD'), price = '" + price
						+ "' where BOOK_ID = '" + updateId + "'";
				dataHandler.dmlQuery(sql);
				dataHandler.commit();
				System.out.println("도서 정보가 수정되었습니다.\n");
				return;

			case 1: // 회원 이름
				System.out.println("현재 이름 : " + name + "\n수정할 이름 : ");
				name = InputHandler.getInput();
				break;

			case 2: // 회원 주소
				System.out.println("현재 작가 : " + author + "\n수정할 작가 : ");
				author = InputHandler.getInput();
				break;

			case 3: // 회원 연락처
				System.out.println("현재 출판사 : " + publisher + "\n수정할 출판사 : ");
				publisher = InputHandler.getInput();
				break;

			case 4: // 회원 생일
				System.out.println("현재 출판일 : " + publishingDate + "\n수정할 출판일 : ");
				publishingDate = InputHandler.getInput();
				break;

			case 5: // 회원 생일
				System.out.println("현재 가격 : " + price + "\n수정할 가격 : ");
				price = InputHandler.getInput();
				break;

			case 6: // 수정 취소
				System.out.println("모든 수정 사항이 초기화 됩니다.\n수정이 취소되었습니다.n");
				break;
			default:
				System.out.println("올바른 값을 입력하세요\n");
				continue;
			}
			System.out.println("변경할 도서 정보를 저장했습니다.");
		}
	}

	public void deleteMemberData() throws SQLException {
		this.showMemberList();
		System.out.println("삭제할 회원 ID : ");
		String memberId = InputHandler.getInput();
		List<String> sql = new ArrayList<String>();
		sql.add("DELETE FROM resign");
		sql.add("INSERT INTO resign SELECT * FROM member WHERE MEMBER_ID = '" + memberId + "'");
		System.out.println("삭제 회원이 백업되었습니다.\n");
		sql.add("DELETE FROM member WHERE MEMBER_ID = '" + memberId + "'");
		dataHandler.dmlQuery(sql);
		System.out.println(memberId + "번 회원이 삭제되었습니다.");
	}

	public void deleteBookData() throws SQLException {
		this.showBookList();
		System.out.println("삭제할 책 ID : ");
		String bookId = InputHandler.getInput();
		String sql = "DELETE FROM book WHERE BOOK_ID = '" + bookId + "'";
		dataHandler.dmlQuery(sql);
		System.out.println(bookId + "번 책이 삭제되었습니다.");
	}

	public void undoDelete() throws SQLException {
		List<String> sql = new ArrayList<String>();
		sql.add("INSERT INTO member SELECT * FROM resign");
		sql.add("DELETE FROM resign");
		dataHandler.dmlQuery(sql);
		System.out.println("가장 최근에 삭제한 회원이 복구되었습니다. ");
	}

	public boolean transactionCheck(String memberId, String BookId) throws SQLException {
		// 유효성 검사
		boolean checkMemberId = false;
		if (memberId != null) {
			checkMemberId = true;
		}

		if (checkMemberId == false) {
			System.out.println("존재하지 않는 회원입니다.");
		}

		// 해당 도서 rent 상태 true 처리
		boolean checkBookId = false;
		if (BookId != null) {
			checkBookId = true;
		}

		if (checkBookId == false) {
			System.out.println("존재하지 않는 도서입니다.");
		}
		if (checkBookId && checkMemberId) {
			return true;
		}
		return false;
	}

	public String[] getIDs() throws SQLException {
		String[] ids = new String[3];
		// 대출할 도서 선택
		System.out.print("도서 이름 : ");
		String rentalId;
		String BookName = InputHandler.getInput();
		String BookId = dataHandler.selectQuery("select book_id from book where name = '" + BookName + "'").get(1)
				.get(0);
		// 어떤 회원이 대출했는지 선택
		System.out.print("회원 이름 : ");
		String memberName = InputHandler.getInput();
		String memberId = dataHandler.selectQuery("select member_id from member where name = '" + memberName + "'")
				.get(1).get(0);
		if (this.transactionCheck(memberId, BookId)) {
			try {
			rentalId = dataHandler.selectQuery(
					"select rental_id from rent where book_id = '" + BookId + "' and member_id = '" + memberId + "'")
					.get(1).get(0);}
			catch(IndexOutOfBoundsException e){
				rentalId = "";
				}
			ids[0] = rentalId;
			ids[1] = BookId;
			ids[2] = memberId;
		} else {
			ids = null;
		}
		return ids;
	}

	public void Rent() throws SQLException {
		System.out.println("=======대출할 도서와 회원의 이름을 입력하세요=======");
		String extension = "연장가능";
		int remaindays = 14;
		List<String> sql = new ArrayList<String>();
		String[] ids = this.getIDs();
		if (ids == null) {
			return;
		}
		String BookId = ids[1];
		String memberId = ids[2];
		System.out.println("미리 연장해서 대출하시겠습니까? : (y/n)");
		String input = InputHandler.getInput().toLowerCase();
		switch (input) {
		case "y": // 연장
			extension = "연장완료";
			remaindays = 21;
			break;
		case "n": // 연장 안함
			extension = "연장가능";
			remaindays = 14;
			break;
		default:
			System.out.println("잘못된 입력입니다.");
		}
		sql.add("INSERT INTO rent (book_id, member_id, extension, rentaldate, returndate, remaindays) VALUES ('"
				+ BookId + "', '" + memberId + "', '" + extension
				+ "', TO_DATE(sysdate, 'YYYY-MM-DD'), to_date(sysdate + " + remaindays + ", 'YYYY-MM-DD'), "
				+ remaindays + ")");
		sql.add("update member set rent_status = '대출중' where member_id = '" + memberId + "'");
		sql.add("update book set rental_status = '대출중' where book_id = '" + BookId + "'");
		dataHandler.dmlQuery(sql);
		System.out.println("대출 처리 되었습니다.");
	}

	public void extens() throws SQLException {
		System.out.println("=======연장할 도서와 회원의 이름을 입력하세요=======");
		String[] ids = this.getIDs();
		if (ids == null) {
			return;
		}
		String rentalId = ids[0];
		String extension = dataHandler.selectQuery("select extension from rent where rental_id = '" + rentalId + "'")
				.get(1).get(0);
		if (extension == "연장완료") {
			System.out.println("이미 연장중인 대출 입니다.");
			return;
		} else {
			dataHandler.dmlQuery("update rent set extension = '연장완료', "
					+ "returndate = to_date(sysdate + 21, 'YYYY-MM-DD'), remaindays = 21 where rental_id = '" + rentalId
					+ "'");
		}
	}

	public void returnBook() throws SQLException {
		System.out.println("=======반납할 도서와 회원의 이름을 입력하세요=======");
		String[] ids = this.getIDs();
		if (ids == null) {
			return;
		}
		List<String> sql = new ArrayList<String>();
		String rentalId = ids[0];
		String BookId = ids[1];
		String memberId = ids[2];
		sql.add("DELETE FROM rent WHERE rental_id = '" + rentalId + "'");
		sql.add("update member set rent_status = '대출가능' where member_id = '" + memberId + "'");
		sql.add("update book set rental_status = '대출가능' where book_id = '" + BookId + "'");
		dataHandler.dmlQuery(sql);
		System.out.println("정상 반납처리 되었습니다.");
	}
}
